/**
 * app.js — Controlador principal de la aplicación.
 * Coordina la interacción entre los módulos Api, TransitionTable, Renderer y la UI.
 */

const App = {

    /** Estado global de la aplicación */
    state: {
        conversionResult: null,  // ConversionResult del backend
        currentNfa: null,        // AutomatonRequest actual
        examples: [],            // Ejemplos predefinidos cargados del backend
        defaultTestStrings: []   // Cadenas de prueba del ejemplo activo
    },

    // ── Inicialización ──────────────────────────────────────────────────

    async init() {
        // Inicializar módulos
        TransitionTable.init('transitionTableContainer');

        // Eventos de navegación
        document.getElementById('mainNav').addEventListener('click', e => {
            const btn = e.target.closest('.tab-btn');
            if (btn) this.switchTab(btn.dataset.tab);
        });

        // Eventos del formulario
        document.getElementById('statesInput').addEventListener('input', () => this.rebuildTable());
        document.getElementById('alphabetInput').addEventListener('input', () => this.rebuildTable());
        document.getElementById('initialStateInput').addEventListener('input', () => this.rebuildTable());
        document.getElementById('acceptStatesInput').addEventListener('input', () => this.rebuildTable());

        // Botón principal de conversión
        document.getElementById('convertBtn').addEventListener('click', () => this.runConversion());

        // Botón limpiar
        document.getElementById('clearBtn').addEventListener('click', () => this.clearAll());

        // Ejemplos
        document.querySelectorAll('.example-btn[data-example]').forEach(btn => {
            btn.addEventListener('click', () => this.loadExample(parseInt(btn.dataset.example)));
        });

        // Cargar ejemplos del backend
        try {
            const data = await Api.getExamples();
            this.state.examples = data.examples || [];
        } catch (err) {
            console.warn('No se pudieron cargar los ejemplos del servidor:', err.message);
            // Continuar sin ejemplos
        }
    },

    // ── Navegación por Tabs ─────────────────────────────────────────────

    switchTab(tabName) {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));

        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
        document.getElementById(`tab-${tabName}`).classList.add('active');
    },

    // ── Tabla de Transiciones ───────────────────────────────────────────

    /**
     * Reconstruye la tabla de transiciones cuando cambian los estados/alfabeto.
     */
    rebuildTable() {
        const states = this.parseList(document.getElementById('statesInput').value);
        const alphabet = this.parseList(document.getElementById('alphabetInput').value);
        const initial = document.getElementById('initialStateInput').value.trim();
        const accepts = this.parseList(document.getElementById('acceptStatesInput').value);

        TransitionTable.render(states, alphabet, initial, accepts, TransitionTable.data);
    },

    // ── Conversión ──────────────────────────────────────────────────────

    /**
     * Ejecuta el proceso completo de conversión AFND → AFD → Minimizar.
     */
    async runConversion() {
        const nfaRequest = this.buildNfaRequest();
        if (!nfaRequest) return;

        this.showLoading(true);

        try {
            const result = await Api.convert(nfaRequest);
            this.state.conversionResult = result;
            this.state.currentNfa = nfaRequest;

            // Renderizar resultados en cada tab
            Renderer.renderConversion(result);
            Renderer.renderMinimization(result);
            Renderer.renderVerificationPanel(
                this.state.defaultTestStrings,
                nfaRequest
            );
           

            // Navegar a la tab de conversión
            this.switchTab('conversion');
            this.showToast('✓ Conversión completada exitosamente', 'success');

        } catch (err) {
            console.error('Error en la conversión:', err);
            this.showToast('✗ Error: ' + err.message, 'error');
        } finally {
            this.showLoading(false);
        }
    },

    // ── Verificación ────────────────────────────────────────────────────

    /**
     * Verifica las cadenas de prueba contra los tres autómatas.
     */
    async runVerification() {
        if (!this.state.currentNfa) {
            this.showToast('Primero ejecuta la conversión del AFND', 'error');
            return;
        }

        const textarea = document.getElementById('testStringsInput');
        if (!textarea) return;

        const testStrings = textarea.value
            .split('\n')
            .map(s => s.trim())
            .filter(s => s !== undefined); // Incluir cadena vacía si está

        if (testStrings.length === 0) {
            this.showToast('Ingresa al menos una cadena de prueba', 'error');
            return;
        }

        this.showLoading(true);

        try {
            const response = await Api.verify(this.state.currentNfa, testStrings);
            Renderer.renderVerificationResults(response);

            const msg = response.allEquivalent
                ? `✓ Los tres autómatas son equivalentes (${testStrings.length} cadenas)`
                : `✗ Discrepancia encontrada — revisa los resultados`;
            this.showToast(msg, response.allEquivalent ? 'success' : 'error');

        } catch (err) {
            console.error('Error en verificación:', err);
            this.showToast('✗ Error: ' + err.message, 'error');
        } finally {
            this.showLoading(false);
        }
    },

    // ── Ejemplos ────────────────────────────────────────────────────────

    /**
     * Carga un ejemplo predefinido de la práctica APE 5.
     * @param {number} index - Índice del ejemplo (0, 1, 2)
     */
    loadExample(index) {
        const example = this.state.examples[index];
        if (!example) {
            this.showToast('Ejemplo no disponible (conecta el backend)', 'error');
            return;
        }

        const { nfa, testStrings } = example;

        // Llenar campos del formulario
        document.getElementById('statesInput').value = nfa.states.join(', ');
        document.getElementById('alphabetInput').value = nfa.alphabet.join(', ');
        document.getElementById('initialStateInput').value = nfa.initialState;
        document.getElementById('acceptStatesInput').value = nfa.acceptStates.join(', ');

        // Cargar transiciones en la tabla
        TransitionTable.loadTransitions(nfa.transitions);
        TransitionTable.render(
            nfa.states, nfa.alphabet,
            nfa.initialState, nfa.acceptStates,
            TransitionTable.data
        );

        this.state.defaultTestStrings = testStrings || [];
        this.showToast(`Ejemplo cargado: ${example.title}`, 'success');
    },

    // ── Limpiar ──────────────────────────────────────────────────────────

    clearAll() {
        document.getElementById('statesInput').value = '';
        document.getElementById('alphabetInput').value = '';
        document.getElementById('initialStateInput').value = '';
        document.getElementById('acceptStatesInput').value = '';
        TransitionTable.clear();
        this.state.conversionResult = null;
        this.state.currentNfa = null;
        this.state.defaultTestStrings = [];
    },

    // ── Construcción del request ────────────────────────────────────────

    /**
     * Construye y valida el AutomatonRequest desde el formulario.
     * @returns {Object|null} El request o null si hay error de validación
     */
    buildNfaRequest() {
        const states   = this.parseList(document.getElementById('statesInput').value);
        const alphabet = this.parseList(document.getElementById('alphabetInput').value);
        const initial  = document.getElementById('initialStateInput').value.trim();
        const accepts  = this.parseList(document.getElementById('acceptStatesInput').value);

        // Validaciones básicas
        if (states.length === 0) {
            this.showToast('Ingresa al menos un estado', 'error'); return null;
        }
        if (alphabet.length === 0) {
            this.showToast('Ingresa al menos un símbolo del alfabeto', 'error'); return null;
        }
        if (!initial) {
            this.showToast('Ingresa el estado inicial', 'error'); return null;
        }
        if (!states.includes(initial)) {
            this.showToast(`El estado inicial "${initial}" no está en Q`, 'error'); return null;
        }
        if (accepts.length === 0) {
            this.showToast('Ingresa al menos un estado de aceptación', 'error'); return null;
        }
        for (const acc of accepts) {
            if (!states.includes(acc)) {
                this.showToast(`El estado de aceptación "${acc}" no está en Q`, 'error'); return null;
            }
        }

        const transitions = TransitionTable.getTransitions();

        return {
            states,
            alphabet,
            initialState: initial,
            acceptStates: accepts,
            transitions
        };
    },

    // ── Utilidades ──────────────────────────────────────────────────────

    /**
     * Parsea una lista de valores separados por comas.
     * @param {string} raw - El texto crudo del input
     * @returns {string[]} Array de valores limpios
     */
    parseList(raw) {
        return (raw || '')
            .split(',')
            .map(s => s.trim())
            .filter(s => s.length > 0);
    },

    showLoading(visible) {
        document.getElementById('loadingOverlay').classList.toggle('visible', visible);
    },

    showToast(message, type = '') {
        const toast = document.getElementById('toast');
        toast.textContent = message;
        toast.className = `toast ${type} show`;

        clearTimeout(this._toastTimeout);
        this._toastTimeout = setTimeout(() => {
            toast.classList.remove('show');
        }, 3500);
    }
};

// ── Bootstrap ──────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => App.init());

// ── Inicialización de tabs de diagramas JFLAP ──────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.diagram-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            // Actualizar botones
            document.querySelectorAll('.diagram-tab-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            // Mostrar panel correspondiente
            document.querySelectorAll('.diag-panel').forEach(p => p.classList.remove('active'));
            const target = document.getElementById('diag-' + btn.dataset.diag);
            if (target) target.classList.add('active');
        });
    });
});
