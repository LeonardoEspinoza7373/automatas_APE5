/**
 * table.js — Gestión de la tabla de transiciones del AFND.
 * Construye dinámicamente la tabla de entrada según los estados y el alfabeto.
 */

const TransitionTable = {

    /** Referencia al contenedor de la tabla */
    container: null,

    /** Datos actuales de la tabla { "q0": { "a": "q1,q2", ... } } */
    data: {},

    /**
     * Inicializa el módulo.
     */
    init(containerId) {
        this.container = document.getElementById(containerId);
    },

    /**
     * Renderiza la tabla de transiciones dada una lista de estados y símbolos.
     * @param {string[]} states - Los estados del AFND
     * @param {string[]} alphabet - Los símbolos del alfabeto
     * @param {string} initialState - Estado inicial
     * @param {string[]} acceptStates - Estados de aceptación
     * @param {Object} existingData - Datos existentes para pre-rellenar
     */
    render(states, alphabet, initialState, acceptStates, existingData = {}) {
        if (!states.length || !alphabet.length) {
            this.container.innerHTML = '<p class="table-placeholder">Ingresa los estados y el alfabeto para generar la tabla</p>';
            return;
        }

        this.data = existingData;

        const table = document.createElement('table');
        table.className = 'nfa-table';

        // ── Encabezado ────────────────────────────────────────────────
        const thead = document.createElement('thead');
        const headerRow = document.createElement('tr');

        const thState = document.createElement('th');
        thState.textContent = 'Estado';
        headerRow.appendChild(thState);

        alphabet.forEach(symbol => {
            const th = document.createElement('th');
            th.textContent = symbol;
            headerRow.appendChild(th);
        });

        thead.appendChild(headerRow);
        table.appendChild(thead);

        // ── Cuerpo ────────────────────────────────────────────────────
        const tbody = document.createElement('tbody');

        states.forEach(state => {
            const row = document.createElement('tr');

            // Celda de estado con badges
            const tdState = document.createElement('td');
            let stateLabelHtml = `<span class="state-badge">${this.escapeHtml(state)}`;
            if (state === initialState) {
                stateLabelHtml += ` <span class="badge-initial">→</span>`;
            }
            if (acceptStates.includes(state)) {
                stateLabelHtml += ` <span class="badge-accept">✓</span>`;
            }
            stateLabelHtml += '</span>';
            tdState.innerHTML = stateLabelHtml;
            row.appendChild(tdState);

            // Celdas de transición por símbolo
            alphabet.forEach(symbol => {
                const td = document.createElement('td');
                const input = document.createElement('input');
                input.type = 'text';
                input.className = 'cell-input';
                input.placeholder = '—';
                input.dataset.state = state;
                input.dataset.symbol = symbol;

                // Pre-rellenar con datos existentes
                const existing = (existingData[state] || {})[symbol];
                if (existing && existing.length > 0) {
                    input.value = existing.join(', ');
                }

                input.addEventListener('change', () => this.updateCell(state, symbol, input.value));
                input.addEventListener('blur', () => this.updateCell(state, symbol, input.value));

                td.appendChild(input);
                row.appendChild(td);
            });

            tbody.appendChild(row);
        });

        table.appendChild(tbody);

        this.container.innerHTML = '';
        this.container.appendChild(table);
    },

    /**
     * Actualiza el dato de una celda en la estructura interna.
     */
    updateCell(state, symbol, value) {
        if (!this.data[state]) this.data[state] = {};

        const trimmed = value.trim();
        if (!trimmed || trimmed === '—' || trimmed === '-') {
            this.data[state][symbol] = [];
        } else {
            // Parsear lista de estados separados por comas
            this.data[state][symbol] = trimmed
                .split(',')
                .map(s => s.trim())
                .filter(s => s.length > 0);
        }
    },

    /**
     * Retorna la tabla de transiciones en el formato esperado por el backend.
     * @returns {Object} { "q0": { "a": ["q1","q2"], ... }, ... }
     */
    getTransitions() {
        // Leer los valores actuales de todos los inputs antes de retornar
        if (this.container) {
            this.container.querySelectorAll('.cell-input').forEach(input => {
                this.updateCell(input.dataset.state, input.dataset.symbol, input.value);
            });
        }
        return this.data;
    },

    /**
     * Carga una tabla de transiciones externa (ej: desde un ejemplo).
     * @param {Object} transitions - Mapa de transiciones del backend/ejemplo
     */
    loadTransitions(transitions) {
        this.data = {};
        for (const [state, symbols] of Object.entries(transitions || {})) {
            this.data[state] = {};
            for (const [symbol, targets] of Object.entries(symbols)) {
                this.data[state][symbol] = targets;
            }
        }
    },

    /**
     * Limpia todos los datos de la tabla.
     */
    clear() {
        this.data = {};
        if (this.container) {
            this.container.innerHTML = '<p class="table-placeholder">Ingresa los estados y el alfabeto para generar la tabla</p>';
        }
    },

    /** Escapa caracteres HTML peligrosos */
    escapeHtml(text) {
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
};
