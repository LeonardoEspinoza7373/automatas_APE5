/**
 * api.js — Cliente HTTP para comunicarse con el backend Spring Boot.
 * Todas las llamadas centralizadas aquí para fácil mantenimiento.
 */

const API_BASE = '/api/automaton';

const Api = {

    /**
     * Convierte un AFND al AFD y lo minimiza.
     * @param {Object} automatonRequest - La definición del AFND
     * @returns {Promise<Object>} ConversionResult del backend
     */
    async convert(automatonRequest) {
        const response = await fetch(`${API_BASE}/convert`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(automatonRequest)
        });

        if (!response.ok) {
            const errorBody = await response.text();
            throw new Error(`Error ${response.status}: ${errorBody}`);
        }

        return response.json();
    },

    /**
     * Verifica cadenas de prueba contra los tres autómatas.
     * @param {Object} nfa - El AFND original
     * @param {string[]} testStrings - Las cadenas a verificar
     * @returns {Promise<Object>} VerificationResponse del backend
     */
    async verify(nfa, testStrings) {
        const response = await fetch(`${API_BASE}/verify`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nfa, testStrings })
        });

        if (!response.ok) {
            const errorBody = await response.text();
            throw new Error(`Error ${response.status}: ${errorBody}`);
        }

        return response.json();
    },

    /**
     * Obtiene los ejemplos predefinidos de la práctica APE 5.
     * @returns {Promise<Object>} Array de ejemplos
     */
    async getExamples() {
        const response = await fetch(`${API_BASE}/examples`);

        if (!response.ok) {
            throw new Error(`Error al cargar ejemplos: ${response.status}`);
        }

        return response.json();
    }
};
