/**
 * render.js — Renderizado de los resultados del backend.
 * Dibuja las tablas de construcción de subconjuntos, pasos de minimización
 * y el resumen comparativo de los tres autómatas.
 */

const Renderer = {

    // ── Conversión (Tab 2) ──────────────────────────────────────────────

    /**
     * Renderiza el contenido completo de la tab de conversión.
     * @param {Object} result - ConversionResult del backend
     */
    renderConversion(result) {
        const container = document.getElementById('conversionContent');
        const { nfa, dfa, subsetSteps, reductionStats } = result;

        container.innerHTML = '';

        // 1. Tarjeta: estadísticas de la conversión
        container.appendChild(this.buildStatsCard(reductionStats));

        // 2. Tarjeta: AFND original
        container.appendChild(this.buildAutomatonCard('AFND Original (entrada)', nfa));

        // 3. Tarjeta: tabla de construcción de subconjuntos
        container.appendChild(this.buildSubsetTableCard(subsetSteps, nfa.alphabet));

        // 4. Tarjeta: AFD resultante
        container.appendChild(this.buildAutomatonCard('AFD Resultante (construcción de subconjuntos)', dfa));
    },

    /**
     * Tarjeta de estadísticas de reducción.
     */
    buildStatsCard(stats) {
        const card = this.card('Estadísticas de Reducción');
        const body = card.querySelector('.card-body');

        body.innerHTML = `
            <div class="stats-row">
                <div class="stat-chip">
                    <span class="stat-value">${stats.nfaStates}</span>
                    <span class="stat-label">Estados AFND</span>
                </div>
                <div class="stat-chip">
                    <span class="stat-value">${stats.dfaStates}</span>
                    <span class="stat-label">Estados AFD</span>
                </div>
                <div class="stat-chip">
                    <span class="stat-value">${stats.minimizedStates}</span>
                    <span class="stat-label">Estados Min.</span>
                </div>
                <div class="stat-chip">
                    <span class="stat-value" style="color:var(--yellow)">${stats.reductionPercentage}%</span>
                    <span class="stat-label">Reducción</span>
                </div>
                <div class="stat-chip">
                    <span class="stat-value">${stats.nfaTransitions}</span>
                    <span class="stat-label">Trans. AFND</span>
                </div>
                <div class="stat-chip">
                    <span class="stat-value">${stats.dfaTransitions}</span>
                    <span class="stat-label">Trans. AFD</span>
                </div>
                <div class="stat-chip">
                    <span class="stat-value">${stats.minimizedTransitions}</span>
                    <span class="stat-label">Trans. Min.</span>
                </div>
            </div>`;

        return card;
    },

    /**
     * Tabla de construcción de subconjuntos.
     */
    buildSubsetTableCard(steps, alphabet) {
        const card = this.card('Tabla de Construcción de Subconjuntos (AFND → AFD)');
        const body = card.querySelector('.card-body');
        body.className = 'card-body scroll-x';

        const table = document.createElement('table');
        table.className = 'result-table';

        // Encabezado
        const thead = document.createElement('thead');
        const headerRow = document.createElement('tr');
        ['Estado AFD', 'Conjunto AFND', ...alphabet, 'Acepta'].forEach(h => {
            const th = document.createElement('th');
            th.textContent = h;
            headerRow.appendChild(th);
        });
        thead.appendChild(headerRow);
        table.appendChild(thead);

        // Filas
        const tbody = document.createElement('tbody');
        steps.forEach(step => {
            const tr = document.createElement('tr');

            // Estado AFD
            const tdState = document.createElement('td');
            tdState.innerHTML = `<span class="tag tag-state">${this.esc(step.dfaState)}</span>`;
            tr.appendChild(tdState);

            // Conjunto AFND
            const tdSet = document.createElement('td');
            tdSet.innerHTML = `{${Array.from(step.nfaStates).map(s => this.esc(s)).join(', ')}}`;
            tr.appendChild(tdSet);

            // Transiciones por símbolo
            alphabet.forEach(sym => {
                const td = document.createElement('td');
                const dest = step.transitions[sym] || '—';
                td.innerHTML = dest === '—' ? '<span style="color:var(--text-dim)">—</span>'
                    : `<span class="tag tag-state">${this.esc(dest)}</span>`;
                tr.appendChild(td);
            });

            // Acepta
            const tdAccept = document.createElement('td');
            tdAccept.innerHTML = step.accept
                ? '<span class="tag tag-accept">✓ Sí</span>'
                : '<span style="color:var(--text-dim)">No</span>';
            tr.appendChild(tdAccept);

            tbody.appendChild(tr);
        });

        table.appendChild(tbody);
        body.appendChild(table);

        return card;
    },

    /**
     * Tarjeta de resumen de un autómata (quintupla).
     */
    buildAutomatonCard(title, automaton) {
        const card = this.card(title);
        const body = card.querySelector('.card-body');

        const fmt = arr => Array.isArray(arr)
            ? `{${arr.map(s => this.esc(s)).join(', ')}}`
            : `{${Array.from(arr).map(s => this.esc(s)).join(', ')}}`;

        body.innerHTML = `
            <div style="display:flex; flex-direction:column; gap:10px;">
                <div class="automaton-field">
                    <span class="automaton-key">Q =</span>
                    <span class="automaton-val">${fmt(automaton.states)}</span>
                </div>
                <div class="automaton-field">
                    <span class="automaton-key">Σ =</span>
                    <span class="automaton-val">${fmt(automaton.alphabet)}</span>
                </div>
                <div class="automaton-field">
                    <span class="automaton-key">q₀ =</span>
                    <span class="automaton-val text-accent">${this.esc(automaton.initialState)}</span>
                </div>
                <div class="automaton-field">
                    <span class="automaton-key">F =</span>
                    <span class="automaton-val">${fmt(automaton.acceptStates)}</span>
                </div>
            </div>
            <hr class="divider">
            ${this.buildTransitionTable(automaton)}`;

        return card;
    },

    /**
     * Tabla de transiciones de un autómata.
     */
    buildTransitionTable(automaton) {
        const alphabet = Array.from(automaton.alphabet);
        const states = Array.from(automaton.states);

        let html = `<p class="section-title">Función de transición δ</p>
            <div class="scroll-x">
            <table class="result-table">
            <thead><tr>
                <th>Estado</th>`;

        alphabet.forEach(sym => { html += `<th>${this.esc(sym)}</th>`; });
        html += '</tr></thead><tbody>';

        states.forEach(state => {
            const isInit = state === automaton.initialState;
            const isAccept = Array.from(automaton.acceptStates).includes(state);
            let stateLabel = this.esc(state);
            if (isInit) stateLabel += ' <span style="color:var(--blue)">→</span>';
            if (isAccept) stateLabel += ' <span style="color:var(--accent)">✓</span>';

            html += `<tr><td>${stateLabel}</td>`;

            alphabet.forEach(sym => {
                const nexts = ((automaton.transitions[state] || {})[sym]) || [];
                const dest = nexts.length > 0 ? nexts.join(', ') : '—';
                html += `<td>${dest === '—' ? '<span style="color:var(--text-dim)">—</span>' : `<span class="tag tag-state">${this.esc(dest)}</span>`}</td>`;
            });

            html += '</tr>';
        });

        html += '</tbody></table></div>';
        return html;
    },

    // ── Minimización (Tab 3) ────────────────────────────────────────────

    /**
     * Renderiza el contenido de la tab de minimización.
     */
    renderMinimization(result) {
        const container = document.getElementById('minimizationContent');
        const { minimizationSteps, minimizedDfa, reductionStats } = result;

        container.innerHTML = '';

        // 1. Reducción
        if (reductionStats.dfaStates === reductionStats.minimizedStates) {
            container.appendChild(this.buildInfoBanner(
                '✓ El AFD ya es mínimo — no se encontraron estados equivalentes que fusionar.'
            ));
        } else {
            container.appendChild(this.buildInfoBanner(
                `Se fusionaron estados: ${reductionStats.dfaStates} → ${reductionStats.minimizedStates} estados (${reductionStats.reductionPercentage}% reducción)`
            ));
        }

        // 2. Pasos del algoritmo
        const stepsCard = this.card('Pasos del Algoritmo de Minimización (Método de la Tabla)');
        const stepsBody = stepsCard.querySelector('.card-body');
        stepsBody.appendChild(this.buildMinimizationSteps(minimizationSteps));
        container.appendChild(stepsCard);

        // 3. AFD minimizado
        container.appendChild(this.buildAutomatonCard('AFD Minimizado (resultado final)', minimizedDfa));
    },

    /**
     * Lista de pasos de minimización con acordeón.
     */
    buildMinimizationSteps(steps) {
        const list = document.createElement('div');
        list.className = 'steps-list';

        steps.forEach((step, idx) => {
            const item = document.createElement('div');
            item.className = 'step-item';
            if (idx === 0) item.classList.add('open');

            item.innerHTML = `
                <div class="step-header">
                    <span class="step-number">${step.iteration}</span>
                    <span class="step-desc">${this.esc(step.description)}</span>
                    <span class="step-toggle">▼</span>
                </div>
                <div class="step-body">
                    ${step.markedPairs.length > 0 ? `
                        <p class="section-title" style="margin-bottom:6px">Pares marcados (distinguibles):</p>
                        <div class="pairs-grid">
                            ${step.markedPairs.map(p => `<span class="pair-chip pair-marked">${this.esc(p)}</span>`).join('')}
                        </div>` : '<p style="color:var(--text-dim);font-size:0.8rem">Sin nuevos pares marcados</p>'}
                    ${step.equivalentPairs.length > 0 ? `
                        <p class="section-title" style="margin-top:12px;margin-bottom:6px">Pares equivalentes (no marcados):</p>
                        <div class="pairs-grid">
                            ${step.equivalentPairs.map(p => `<span class="pair-chip pair-equiv">${this.esc(p)}</span>`).join('')}
                        </div>` : ''}
                </div>`;

            item.querySelector('.step-header').addEventListener('click', () => {
                item.classList.toggle('open');
            });

            list.appendChild(item);
        });

        return list;
    },

    // ── Verificación (Tab 4) ────────────────────────────────────────────

    /**
     * Renderiza el panel de verificación con el formulario y los resultados.
     */
    renderVerificationPanel(testStrings, currentNfa) {
        const container = document.getElementById('verificationContent');
        container.innerHTML = '';

        // Input area
        const inputArea = document.createElement('div');
        inputArea.className = 'verify-input-area';

        const isMultiChar = Array.from(currentNfa.alphabet).some(s => s.length > 1);
        const hint = isMultiChar
            ? 'Tokens separados por espacios, una cadena por línea. Ejemplo: @bot user cmd'
            : 'Un símbolo por carácter, una cadena por línea. Ejemplo: KGF';

        inputArea.innerHTML = `
            <div>
                <label class="field-label">Cadenas de prueba</label>
                <p class="field-hint">${hint}</p>
            </div>
            <textarea class="strings-textarea" id="testStringsInput" 
                placeholder="Una cadena por línea...">${testStrings.join('\n')}</textarea>
            <div class="verify-actions">
                <button class="btn-primary" id="verifyBtn">
                    <span class="btn-icon">✓</span> Verificar Equivalencia
                </button>
                <button class="btn-secondary" id="clearResultsBtn">Limpiar</button>
                <span class="text-muted text-small" id="verifyHint">
                    Mínimo 20 cadenas recomendadas para la práctica
                </span>
            </div>`;

        container.appendChild(inputArea);

        // Contenedor de resultados
        const resultsContainer = document.createElement('div');
        resultsContainer.id = 'verifyResults';
        container.appendChild(resultsContainer);

        // Eventos
        document.getElementById('verifyBtn').addEventListener('click', () => {
            App.runVerification();
        });

        document.getElementById('clearResultsBtn').addEventListener('click', () => {
            document.getElementById('verifyResults').innerHTML = '';
        });
    },

    /**
     * Muestra los resultados de verificación.
     */
    renderVerificationResults(response) {
        const container = document.getElementById('verifyResults');
        container.innerHTML = '';

        // Banner de equivalencia
        const banner = document.createElement('div');
        banner.className = `equiv-banner ${response.allEquivalent ? 'success' : 'warning'}`;
        banner.innerHTML = `
            <span class="equiv-icon">${response.allEquivalent ? '✓' : '✗'}</span>
            <div>
                <strong>${response.allEquivalent
                    ? 'Los tres autómatas son equivalentes'
                    : 'Discrepancia detectada entre autómatas'}</strong>
                <div style="font-size:0.78rem;margin-top:2px;opacity:0.8">
                    ${response.totalTested} cadenas probadas — 
                    ${response.accepted} aceptadas, ${response.rejected} rechazadas
                </div>
            </div>`;
        container.appendChild(banner);

        // Tabla de resultados
        const tableCard = this.card('Resultados de Verificación');
        const body = tableCard.querySelector('.card-body');
        body.className = 'card-body scroll-x';

        const table = document.createElement('table');
        table.className = 'result-table';

        table.innerHTML = `
            <thead>
                <tr>
                    <th>#</th>
                    <th>Cadena</th>
                    <th>AFND</th>
                    <th>AFD</th>
                    <th>AFD Min.</th>
                    <th>Equivalente</th>
                </tr>
            </thead>`;

        const tbody = document.createElement('tbody');
        response.results.forEach((r, idx) => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="color:var(--text-dim)">${idx + 1}</td>
                <td><code style="font-family:var(--mono);font-size:0.78rem">${r.input === '' ? '(vacía)' : this.esc(r.input)}</code></td>
                <td>${r.nfaResult ? '<span class="tag tag-accept">✓</span>' : '<span class="tag tag-reject">✗</span>'}</td>
                <td>${r.dfaResult ? '<span class="tag tag-accept">✓</span>' : '<span class="tag tag-reject">✗</span>'}</td>
                <td>${r.minimizedResult ? '<span class="tag tag-accept">✓</span>' : '<span class="tag tag-reject">✗</span>'}</td>
                <td>${r.equivalent ? '<span class="tag tag-ok">✓ Sí</span>' : '<span class="tag tag-diff">✗ No</span>'}</td>`;
            tbody.appendChild(tr);
        });

        table.appendChild(tbody);
        body.appendChild(table);
        container.appendChild(tableCard);
    },

    // ── Utilidades ──────────────────────────────────────────────────────

    /**
     * Crea una tarjeta con encabezado y cuerpo.
     */
    card(title) {
        const div = document.createElement('div');
        div.className = 'card';
        div.innerHTML = `
            <div class="card-header">
                <span class="card-title">${this.esc(title)}</span>
            </div>
            <div class="card-body"></div>`;
        return div;
    },

    /**
     * Banner informativo.
     */
    buildInfoBanner(message) {
        const div = document.createElement('div');
        div.className = 'equiv-banner success';
        div.innerHTML = `<span class="equiv-icon">ℹ</span> <span>${this.esc(message)}</span>`;
        return div;
    },

    /** Escapa HTML */
    esc(text) {
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
};

// ── Análisis Comparativo (Tab 6) ────────────────────────────────────

/**
 

    // ── 1. Tabla de reducción ───────────────────────────────────────
    const tableSection = this._analysisSection('📊', 'Tabla Comparativa de Reducción de Estados');
    tableSection.querySelector('.analysis-body').innerHTML = `
        <table class="analysis-table">
            <thead>
                <tr>
                    <th>Autómata</th>
                    <th>Nº de Estados</th>
                    <th>Nº de Transiciones</th>
                    <th>Reducción vs AFD</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>AFND Original</td>
                    <td>${nfaStates}</td>
                    <td>${nfaTrans}</td>
                    <td>—</td>
                </tr>
                <tr>
                    <td>AFD (Subconjuntos)</td>
                    <td>${dfaStates}</td>
                    <td>${dfaTrans}</td>
                    <td>—</td>
                </tr>
                <tr style="font-weight:bold">
                    <td>AFD Minimizado</td>
                    <td style="color:var(--accent)">${minStates}</td>
                    <td style="color:var(--accent)">${minTrans}</td>
                    <td style="color:var(--accent)">${reduction}% menos estados</td>
                </tr>
            </tbody>
        </table>
        <div class="analysis-highlight">
            ${sameMin
                ? `✓ El AFD obtenido por construcción de subconjuntos ya era mínimo. No se encontraron estados equivalentes que fusionar.`
                : `✓ Se fusionaron ${fusedCount} estado(s): el AFD pasó de ${dfaStates} a ${minStates} estados, una reducción del ${reduction}%.`
            }
        </div>`;
    container.appendChild(tableSection);

    // ── 2. Análisis de reducción ────────────────────────────────────
    const reductionSection = this._analysisSection('🔬', 'Análisis de la Reducción de Estados');
    reductionSection.querySelector('.analysis-body').innerHTML = `
        <p>El proceso de conversión de un Autómata Finito No Determinista (AFND) a un Autómata Finito Determinista (AFD) 
        mediante el algoritmo de construcción de subconjuntos generó un AFD con <strong>${dfaStates} estados</strong>, 
        partiendo de un AFND con <strong>${nfaStates} estados</strong>. Este incremento es característico del algoritmo, 
        ya que cada estado del AFD representa un subconjunto posible de estados del AFND, y en el peor caso teórico 
        pueden generarse hasta 2ⁿ estados, donde n es el número de estados del AFND original.</p>

        <p>Tras aplicar el algoritmo de minimización por tabla de equivalencia de pares de estados, el AFD quedó 
        reducido a <strong>${minStates} estados</strong>${sameMin 
            ? ', confirmando que el AFD construido ya era óptimo. Esto ocurre cuando ningún par de estados del AFD es equivalente, es decir, para cada par de estados existe al menos una cadena que los distingue.'
            : `, lo que representa una reducción del <strong>${reduction}%</strong> con respecto al AFD por subconjuntos. Los ${fusedCount} estado(s) fusionados eran equivalentes, es decir, desde cualquiera de ellos se aceptaban y rechazaban exactamente las mismas cadenas.`
        }</p>

        <p>La equivalencia entre el AFND original, el AFD por subconjuntos y el AFD minimizado fue verificada 
        experimentalmente mediante un conjunto de cadenas de prueba que cubre los casos: cadenas vacías (longitud 0), 
        cadenas cortas (longitud 1-2), cadenas medianas (longitud 3-5), cadenas largas (longitud 6+), cadenas con 
        símbolos repetidos y cadenas frontera que están en el límite entre aceptación y rechazo. En todos los casos, 
        los tres autómatas produjeron resultados idénticos, demostrando la equivalencia formal.</p>`;
    container.appendChild(reductionSection);

    // ── 3. Impacto en eficiencia ────────────────────────────────────
    const efficiencySection = this._analysisSection('⚡', 'Importancia Práctica: Eficiencia de Memoria y Tiempo de Ejecución');
    efficiencySection.querySelector('.analysis-body').innerHTML = `
        <p>La minimización de autómatas finitos tiene un impacto directo y cuantificable en la eficiencia de los 
        sistemas que los implementan. En términos de <strong>memoria</strong>, cada estado de un AFD requiere almacenar 
        su tabla de transiciones completa: |Q| × |Σ| entradas. Pasar de ${dfaStates} a ${minStates} estados con un 
        alfabeto de ${Array.from(dfa.alphabet || []).length} símbolos reduce el consumo de memoria de 
        <strong>${dfaStates * Array.from(dfa.alphabet || []).length} entradas</strong> a 
        <strong>${minStates * Array.from(minimizedDfa.alphabet || []).length} entradas</strong> en la tabla de transiciones.</p>

        <p>En cuanto al <strong>tiempo de ejecución</strong>, cada paso de la simulación de un AFD requiere una 
        consulta a la tabla de transiciones del estado actual. Un autómata con menos estados no reduce el tiempo 
        por símbolo (que sigue siendo O(1) con una tabla hash), pero sí reduce el espacio de búsqueda en algoritmos 
        que iteran sobre estados, como la propia verificación de equivalencia entre autómatas, la composición de 
        autómatas o la generación de expresiones regulares equivalentes.</p>

        <p>Dos aplicaciones concretas donde la minimización es crítica son: (1) <strong>Compiladores e intérpretes</strong>, 
        donde el análisis léxico se implementa mediante AFDs. Un lexer con estados mínimos procesa el código fuente 
        más rápido y consume menos memoria caché, lo que es especialmente relevante en compiladores de producción 
        como GCC o LLVM que analizan millones de tokens. (2) <strong>Búsqueda de patrones en texto</strong> 
        (grep, motores de expresiones regulares), donde el AFD minimizado permite rechazar cadenas inválidas 
        en el menor número posible de pasos, optimizando el rendimiento en búsquedas sobre grandes volúmenes de 
        datos como registros de servidor o bases de datos de secuencias genéticas.</p>`;
    container.appendChild(efficiencySection);

    // ── 4. Limitaciones ────────────────────────────────────────────
    const limitsSection = this._analysisSection('⚠', 'Limitaciones del Algoritmo de Minimización');
    limitsSection.querySelector('.analysis-body').innerHTML = `
        <p>El algoritmo de minimización por tabla de equivalencia de pares (también conocido como algoritmo de 
        Hopcroft o método de la tabla de marcado) presenta varias limitaciones que es importante considerar 
        en aplicaciones prácticas:</p>

        <p><strong>1. Complejidad temporal y espacial:</strong> El algoritmo clásico de tabla de pares tiene 
        complejidad O(n² × |Σ|) en tiempo y O(n²) en espacio, donde n es el número de estados del AFD. Para 
        autómatas con cientos o miles de estados (comunes en análisis léxico de lenguajes reales), esto puede 
        representar un costo significativo. La variante de Hopcroft mejora esto a O(n log n × |Σ|), pero 
        su implementación es considerablemente más compleja.</p>

        <p><strong>2. Solo aplica a AFDs completos:</strong> El algoritmo requiere que el AFD sea completo, 
        es decir, que cada estado tenga definida una transición para cada símbolo del alfabeto. Los estados 
        de error (como ERR = ∅ en este proyecto) son necesarios para completar el autómata antes de minimizar. 
        Si el AFD tiene transiciones indefinidas, el resultado puede ser incorrecto.</p>

        <p><strong>3. No aplica directamente a AFNDs:</strong> El algoritmo de minimización requiere como entrada 
        un AFD. No existe un equivalente directo para AFNDs, por lo que el proceso siempre requiere la conversión 
        previa mediante construcción de subconjuntos, que puede generar una explosión exponencial de estados.</p>

        <p><strong>4. El AFD minimizado es único (salvo renombramiento):</strong> Una propiedad importante y también 
        una limitación es que el AFD mínimo de un lenguaje regular es único hasta isomorfismo. Esto significa que 
        si dos implementaciones diferentes minimizan el mismo AFND, obtendrán AFDs estructuralmente idénticos 
        (aunque los estados puedan tener nombres distintos). Esto garantiza un resultado canónico, pero impide 
        optimizaciones adicionales más allá del mínimo teórico.</p>`;
    container.appendChild(limitsSection);

    // ── 5. Conclusiones ────────────────────────────────────────────
    const conclusionSection = this._analysisSection('✅', 'Conclusiones');
    const wordEstimate = 420;
    conclusionSection.querySelector('.analysis-section-header').innerHTML += 
        `<span class="word-count-badge">≈ ${wordEstimate} palabras</span>`;
    conclusionSection.querySelector('.analysis-body').innerHTML = `
        <p>La práctica APE 005 demostró de manera experimental la cadena completa de transformaciones formales 
        sobre autómatas finitos: AFND → AFD (construcción de subconjuntos) → AFD Minimizado (tabla de equivalencia). 
        Los tres autómatas resultantes fueron verificados con ${'>'}20 cadenas de prueba, confirmando su equivalencia 
        semántica: reconocen exactamente el mismo lenguaje formal.</p>

        <p>La implementación en <strong>Spring Boot 3.2 + Java 21</strong> como backend REST y HTML/CSS/JavaScript 
        como frontend permitió separar claramente la lógica algorítmica (servicios Java) de la presentación 
        (interfaz web), siguiendo los principios de código limpio: responsabilidad única, inyección de dependencias 
        y nombres descriptivos en cada clase y método.</p>

        <p>Los resultados confirman que la minimización es una herramienta fundamental en la teoría de autómatas 
        con aplicaciones directas en compiladores, análisis léxico, búsqueda de patrones y sistemas de validación 
        de protocolos. La combinación de visualización paso a paso del algoritmo con la verificación experimental 
        de equivalencia constituye una demostración completa y rigurosa de los conceptos teóricos estudiados en la 
        asignatura.</p>`;
    container.appendChild(conclusionSection);
};

/**
 * Crea una sección de análisis con encabezado y cuerpo.
 */

