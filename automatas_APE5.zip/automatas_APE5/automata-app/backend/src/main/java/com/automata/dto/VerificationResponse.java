package com.automata.dto;

import java.util.List;

/**
 * DTO de respuesta con los resultados de verificación de cadenas
 * para los tres autómatas.
 */
public class VerificationResponse {

    private List<StringTestResult> results;
    private boolean allEquivalent;
    private int totalTested;
    private int accepted;
    private int rejected;

    public static class StringTestResult {
        private String input;
        private boolean nfaResult;
        private boolean dfaResult;
        private boolean minimizedResult;
        private boolean equivalent;

        public StringTestResult() {}

        public StringTestResult(String input, boolean nfaResult,
                                boolean dfaResult, boolean minimizedResult) {
            this.input = input;
            this.nfaResult = nfaResult;
            this.dfaResult = dfaResult;
            this.minimizedResult = minimizedResult;
            this.equivalent = (nfaResult == dfaResult) && (dfaResult == minimizedResult);
        }

        public String getInput() { return input; }
        public void setInput(String input) { this.input = input; }

        public boolean isNfaResult() { return nfaResult; }
        public void setNfaResult(boolean nfaResult) { this.nfaResult = nfaResult; }

        public boolean isDfaResult() { return dfaResult; }
        public void setDfaResult(boolean dfaResult) { this.dfaResult = dfaResult; }

        public boolean isMinimizedResult() { return minimizedResult; }
        public void setMinimizedResult(boolean minimizedResult) {
            this.minimizedResult = minimizedResult;
        }

        public boolean isEquivalent() { return equivalent; }
        public void setEquivalent(boolean equivalent) { this.equivalent = equivalent; }
    }

    public List<StringTestResult> getResults() { return results; }
    public void setResults(List<StringTestResult> results) { this.results = results; }

    public boolean isAllEquivalent() { return allEquivalent; }
    public void setAllEquivalent(boolean allEquivalent) { this.allEquivalent = allEquivalent; }

    public int getTotalTested() { return totalTested; }
    public void setTotalTested(int totalTested) { this.totalTested = totalTested; }

    public int getAccepted() { return accepted; }
    public void setAccepted(int accepted) { this.accepted = accepted; }

    public int getRejected() { return rejected; }
    public void setRejected(int rejected) { this.rejected = rejected; }
}
