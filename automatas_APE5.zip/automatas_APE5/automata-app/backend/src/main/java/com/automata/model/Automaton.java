package com.automata.model;

import java.util.*;

/**
 * Modelo base para representar un Autómata Finito (NFA o DFA).
 * Encapsula todos los componentes de la quíntupla formal: (Q, Σ, δ, q0, F).
 */
public class Automaton {

    /** Conjunto de todos los estados Q */
    private Set<String> states;

    /** Alfabeto Σ */
    private Set<String> alphabet;

    /**
     * Función de transición δ: estado × símbolo → conjunto de estados.
     * Estructura: Map< estadoOrigen, Map< símbolo, Set<estadoDestino> > >
     */
    private Map<String, Map<String, Set<String>>> transitions;

    /** Estado inicial q0 */
    private String initialState;

    /** Conjunto de estados de aceptación F */
    private Set<String> acceptStates;

    /** Tipo de autómata para referencia */
    private AutomatonType type;

    public enum AutomatonType {
        NFA, DFA, MINIMIZED_DFA
    }

    public Automaton() {
        this.states = new LinkedHashSet<>();
        this.alphabet = new LinkedHashSet<>();
        this.transitions = new LinkedHashMap<>();
        this.acceptStates = new LinkedHashSet<>();
    }

    // ── Getters & Setters ────────────────────────────────────────────────────

    public Set<String> getStates() { return states; }
    public void setStates(Set<String> states) { this.states = states; }

    public Set<String> getAlphabet() { return alphabet; }
    public void setAlphabet(Set<String> alphabet) { this.alphabet = alphabet; }

    public Map<String, Map<String, Set<String>>> getTransitions() { return transitions; }
    public void setTransitions(Map<String, Map<String, Set<String>>> transitions) {
        this.transitions = transitions;
    }

    public String getInitialState() { return initialState; }
    public void setInitialState(String initialState) { this.initialState = initialState; }

    public Set<String> getAcceptStates() { return acceptStates; }
    public void setAcceptStates(Set<String> acceptStates) { this.acceptStates = acceptStates; }

    public AutomatonType getType() { return type; }
    public void setType(AutomatonType type) { this.type = type; }

    // ── Métodos utilitarios ──────────────────────────────────────────────────

    /**
     * Obtiene los estados destino desde un estado origen con un símbolo dado.
     * Retorna conjunto vacío si no existe transición.
     */
    public Set<String> getNextStates(String fromState, String symbol) {
        return transitions
                .getOrDefault(fromState, Collections.emptyMap())
                .getOrDefault(symbol, Collections.emptySet());
    }

    /**
     * Agrega una transición al autómata.
     */
    public void addTransition(String fromState, String symbol, String toState) {
        transitions
                .computeIfAbsent(fromState, k -> new LinkedHashMap<>())
                .computeIfAbsent(symbol, k -> new LinkedHashSet<>())
                .add(toState);
    }

    /**
     * Verifica si un estado es de aceptación.
     */
    public boolean isAcceptState(String state) {
        return acceptStates.contains(state);
    }

    /**
     * Verifica si el conjunto de estados contiene al menos uno de aceptación.
     */
    public boolean containsAcceptState(Set<String> stateSet) {
        return stateSet.stream().anyMatch(acceptStates::contains);
    }
}
