package com.automata.dto;

import java.util.List;

/**
 * DTO para solicitar la verificación de cadenas de prueba
 * contra los tres autómatas (AFND, AFD, AFD mínimo).
 */
public class VerificationRequest {

    /** Definición del AFND original */
    private AutomatonRequest nfa;

    /** Lista de cadenas a verificar */
    private List<String> testStrings;

    public AutomatonRequest getNfa() { return nfa; }
    public void setNfa(AutomatonRequest nfa) { this.nfa = nfa; }

    public List<String> getTestStrings() { return testStrings; }
    public void setTestStrings(List<String> testStrings) { this.testStrings = testStrings; }
}
