package com.automata.service;

import com.automata.dto.AutomatonRequest;
import com.automata.dto.VerificationRequest;
import com.automata.dto.VerificationResponse;
import com.automata.model.Automaton;
import com.automata.model.ConversionResult;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Servicio orquestador que coordina el pipeline completo:
 *   AutomatonRequest → AFND → AFD → AFD Minimizado → Verificación
 *
 * Actúa como fachada entre el controlador y los servicios especializados.
 */
@Service
public class AutomatonService {

    private final SubsetConstructionService subsetConstructionService;
    private final DfaMinimizationService dfaMinimizationService;
    private final StringVerificationService stringVerificationService;

    public AutomatonService(SubsetConstructionService subsetConstructionService,
                            DfaMinimizationService dfaMinimizationService,
                            StringVerificationService stringVerificationService) {
        this.subsetConstructionService = subsetConstructionService;
        this.dfaMinimizationService = dfaMinimizationService;
        this.stringVerificationService = stringVerificationService;
    }

    /**
     * Ejecuta el proceso completo: AFND → AFD → AFD Minimizado.
     *
     * @param request La definición del AFND desde el frontend
     * @return El resultado completo con todos los pasos y estadísticas
     */
    public ConversionResult processConversion(AutomatonRequest request) {
        ConversionResult result = new ConversionResult();

        // 1. Construir el AFND desde el request
        Automaton nfa = buildAutomatonFromRequest(request, Automaton.AutomatonType.NFA);
        result.setNfa(nfa);

        // 2. Convertir AFND → AFD (construcción de subconjuntos)
        Automaton dfa = subsetConstructionService.convert(nfa, result);
        result.setDfa(dfa);

        // 3. Minimizar el AFD
        Automaton minimizedDfa = dfaMinimizationService.minimize(dfa, result);
        result.setMinimizedDfa(minimizedDfa);

        // 4. Calcular estadísticas de reducción
        result.setReductionStats(calculateReductionStats(nfa, dfa, minimizedDfa));

        return result;
    }

    /**
     * Verifica un conjunto de cadenas contra los tres autómatas
     * y comprueba que los resultados sean idénticos (equivalencia).
     *
     * @param request Contiene la definición del AFND y las cadenas de prueba
     * @return Los resultados de verificación con indicador de equivalencia
     */
    public VerificationResponse verifyStrings(VerificationRequest request) {
        // Reconstruir los tres autómatas
        ConversionResult conversion = processConversion(request.getNfa());
        Automaton nfa = conversion.getNfa();
        Automaton dfa = conversion.getDfa();
        Automaton minimizedDfa = conversion.getMinimizedDfa();

        List<VerificationResponse.StringTestResult> results = new ArrayList<>();
        int accepted = 0;
        boolean allEquivalent = true;

        for (String testString : request.getTestStrings()) {
            // Tokenizar la cadena según el alfabeto
            List<String> tokens = stringVerificationService.tokenize(testString, nfa.getAlphabet());

            boolean nfaResult = false;
            boolean dfaResult = false;
            boolean minResult = false;

            if (tokens != null) {
                nfaResult = stringVerificationService.verifyNfa(nfa, tokens);
                dfaResult = stringVerificationService.verifyDfa(dfa, tokens);
                minResult = stringVerificationService.verifyDfa(minimizedDfa, tokens);
            }

            VerificationResponse.StringTestResult testResult =
                    new VerificationResponse.StringTestResult(testString, nfaResult, dfaResult, minResult);

            results.add(testResult);

            if (nfaResult) accepted++;
            if (!testResult.isEquivalent()) allEquivalent = false;
        }

        VerificationResponse response = new VerificationResponse();
        response.setResults(results);
        response.setAllEquivalent(allEquivalent);
        response.setTotalTested(results.size());
        response.setAccepted(accepted);
        response.setRejected(results.size() - accepted);

        return response;
    }

    /**
     * Construye un objeto Automaton a partir de un AutomatonRequest.
     */
    private Automaton buildAutomatonFromRequest(AutomatonRequest request, Automaton.AutomatonType type) {
        Automaton automaton = new Automaton();
        automaton.setType(type);
        automaton.setStates(new LinkedHashSet<>(request.getStates()));
        automaton.setAlphabet(new LinkedHashSet<>(request.getAlphabet()));
        automaton.setInitialState(request.getInitialState());
        automaton.setAcceptStates(new LinkedHashSet<>(request.getAcceptStates()));

        // Convertir transiciones del request al formato interno
        if (request.getTransitions() != null) {
            for (Map.Entry<String, Map<String, List<String>>> stateEntry
                    : request.getTransitions().entrySet()) {
                String fromState = stateEntry.getKey();
                for (Map.Entry<String, List<String>> symbolEntry
                        : stateEntry.getValue().entrySet()) {
                    String symbol = symbolEntry.getKey();
                    for (String toState : symbolEntry.getValue()) {
                        automaton.addTransition(fromState, symbol, toState);
                    }
                }
            }
        }

        return automaton;
    }

    /**
     * Calcula las estadísticas de reducción entre los tres autómatas.
     */
    private ConversionResult.ReductionStats calculateReductionStats(
            Automaton nfa, Automaton dfa, Automaton minimizedDfa) {

        ConversionResult.ReductionStats stats = new ConversionResult.ReductionStats();
        stats.setNfaStates(nfa.getStates().size());
        stats.setDfaStates(dfa.getStates().size());
        stats.setMinimizedStates(minimizedDfa.getStates().size());

        stats.setNfaTransitions(subsetConstructionService.countTransitions(nfa));
        stats.setDfaTransitions(subsetConstructionService.countTransitions(dfa));
        stats.setMinimizedTransitions(subsetConstructionService.countTransitions(minimizedDfa));

        // Porcentaje de reducción del AFD al AFD minimizado
        if (dfa.getStates().size() > 0) {
            double reduction = 1.0 - ((double) minimizedDfa.getStates().size()
                    / dfa.getStates().size());
            stats.setReductionPercentage(Math.round(reduction * 1000.0) / 10.0);
        }

        return stats;
    }
}
