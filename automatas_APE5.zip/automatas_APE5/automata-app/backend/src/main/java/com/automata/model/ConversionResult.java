package com.automata.model;

import java.util.*;

/**
 * Encapsula el resultado completo del proceso de conversión AFND → AFD → AFD Minimizado.
 * Incluye todos los pasos intermedios para visualización.
 */
public class ConversionResult {

    /** El AFND original ingresado por el usuario */
    private Automaton nfa;

    /** El AFD resultante de la construcción de subconjuntos */
    private Automaton dfa;

    /** El AFD mínimo tras aplicar el algoritmo de minimización */
    private Automaton minimizedDfa;

    /** Pasos de la construcción de subconjuntos (tabla de transformación) */
    private List<SubsetConstructionStep> subsetSteps;

    /** Pasos del algoritmo de minimización (iteraciones de la tabla de pares) */
    private List<MinimizationStep> minimizationSteps;

    /** Estadísticas de reducción */
    private ReductionStats reductionStats;

    // ── Constructores ────────────────────────────────────────────────────────

    public ConversionResult() {
        this.subsetSteps = new ArrayList<>();
        this.minimizationSteps = new ArrayList<>();
    }

    // ── Clases internas de datos ─────────────────────────────────────────────

    /**
     * Un paso en la tabla de construcción de subconjuntos.
     */
    public static class SubsetConstructionStep {
        private String dfaState;
        private Set<String> nfaStates;
        private Map<String, String> transitions; // símbolo → estado AFD destino
        private boolean isAccept;
        private boolean isNew;

        public SubsetConstructionStep() {
            this.nfaStates = new LinkedHashSet<>();
            this.transitions = new LinkedHashMap<>();
        }

        public String getDfaState() { return dfaState; }
        public void setDfaState(String dfaState) { this.dfaState = dfaState; }

        public Set<String> getNfaStates() { return nfaStates; }
        public void setNfaStates(Set<String> nfaStates) { this.nfaStates = nfaStates; }

        public Map<String, String> getTransitions() { return transitions; }
        public void setTransitions(Map<String, String> transitions) { this.transitions = transitions; }

        public boolean isAccept() { return isAccept; }
        public void setAccept(boolean accept) { isAccept = accept; }

        public boolean isNew() { return isNew; }
        public void setNew(boolean aNew) { isNew = aNew; }
    }

    /**
     * Un paso en el proceso de minimización (una iteración de la tabla de pares).
     */
    public static class MinimizationStep {
        private int iteration;
        private String description;
        private List<String> markedPairs;
        private List<String> equivalentPairs;

        public MinimizationStep() {
            this.markedPairs = new ArrayList<>();
            this.equivalentPairs = new ArrayList<>();
        }

        public int getIteration() { return iteration; }
        public void setIteration(int iteration) { this.iteration = iteration; }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }

        public List<String> getMarkedPairs() { return markedPairs; }
        public void setMarkedPairs(List<String> markedPairs) { this.markedPairs = markedPairs; }

        public List<String> getEquivalentPairs() { return equivalentPairs; }
        public void setEquivalentPairs(List<String> equivalentPairs) {
            this.equivalentPairs = equivalentPairs;
        }
    }

    /**
     * Estadísticas comparativas de reducción de estados.
     */
    public static class ReductionStats {
        private int nfaStates;
        private int dfaStates;
        private int minimizedStates;
        private double reductionPercentage;
        private int nfaTransitions;
        private int dfaTransitions;
        private int minimizedTransitions;

        public int getNfaStates() { return nfaStates; }
        public void setNfaStates(int nfaStates) { this.nfaStates = nfaStates; }

        public int getDfaStates() { return dfaStates; }
        public void setDfaStates(int dfaStates) { this.dfaStates = dfaStates; }

        public int getMinimizedStates() { return minimizedStates; }
        public void setMinimizedStates(int minimizedStates) { this.minimizedStates = minimizedStates; }

        public double getReductionPercentage() { return reductionPercentage; }
        public void setReductionPercentage(double reductionPercentage) {
            this.reductionPercentage = reductionPercentage;
        }

        public int getNfaTransitions() { return nfaTransitions; }
        public void setNfaTransitions(int nfaTransitions) { this.nfaTransitions = nfaTransitions; }

        public int getDfaTransitions() { return dfaTransitions; }
        public void setDfaTransitions(int dfaTransitions) { this.dfaTransitions = dfaTransitions; }

        public int getMinimizedTransitions() { return minimizedTransitions; }
        public void setMinimizedTransitions(int minimizedTransitions) {
            this.minimizedTransitions = minimizedTransitions;
        }
    }

    // ── Getters & Setters principales ────────────────────────────────────────

    public Automaton getNfa() { return nfa; }
    public void setNfa(Automaton nfa) { this.nfa = nfa; }

    public Automaton getDfa() { return dfa; }
    public void setDfa(Automaton dfa) { this.dfa = dfa; }

    public Automaton getMinimizedDfa() { return minimizedDfa; }
    public void setMinimizedDfa(Automaton minimizedDfa) { this.minimizedDfa = minimizedDfa; }

    public List<SubsetConstructionStep> getSubsetSteps() { return subsetSteps; }
    public void setSubsetSteps(List<SubsetConstructionStep> subsetSteps) {
        this.subsetSteps = subsetSteps;
    }

    public List<MinimizationStep> getMinimizationSteps() { return minimizationSteps; }
    public void setMinimizationSteps(List<MinimizationStep> minimizationSteps) {
        this.minimizationSteps = minimizationSteps;
    }

    public ReductionStats getReductionStats() { return reductionStats; }
    public void setReductionStats(ReductionStats reductionStats) {
        this.reductionStats = reductionStats;
    }
}
