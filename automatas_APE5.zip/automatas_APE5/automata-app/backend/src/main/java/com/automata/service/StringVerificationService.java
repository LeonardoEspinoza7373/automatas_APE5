package com.automata.service;

import com.automata.model.Automaton;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Servicio para verificar si una cadena es aceptada o rechazada
 * por un autómata finito (NFA o DFA).
 *
 * Para el NFA usa simulación por backtracking/conjuntos de estados activos.
 * Para el DFA/minimizado sigue la función de transición determinista.
 */
@Service
public class StringVerificationService {

    /**
     * Verifica si una cadena es aceptada por un NFA.
     * Mantiene el conjunto de todos los estados activos simultáneamente.
     *
     * @param nfa El autómata finito no determinista
     * @param input Los tokens de la cadena de entrada
     * @return true si la cadena es aceptada
     */
    public boolean verifyNfa(Automaton nfa, List<String> input) {
        // Conjunto de estados activos (simulación paralela)
        Set<String> activeStates = new LinkedHashSet<>();
        activeStates.add(nfa.getInitialState());

        for (String symbol : input) {
            Set<String> nextStates = new LinkedHashSet<>();
            for (String state : activeStates) {
                nextStates.addAll(nfa.getNextStates(state, symbol));
            }
            activeStates = nextStates;

            if (activeStates.isEmpty()) {
                return false; // Ningún estado activo → rechazada
            }
        }

        // Aceptar si algún estado activo es de aceptación
        return nfa.containsAcceptState(activeStates);
    }

    /**
     * Verifica si una cadena es aceptada por un DFA (determinista).
     * Sigue una sola ruta de estados.
     *
     * @param dfa El autómata finito determinista
     * @param input Los tokens de la cadena de entrada
     * @return true si la cadena es aceptada
     */
    public boolean verifyDfa(Automaton dfa, List<String> input) {
        String currentState = dfa.getInitialState();

        for (String symbol : input) {
            Set<String> nextStates = dfa.getNextStates(currentState, symbol);
            if (nextStates.isEmpty()) {
                return false; // Sin transición → rechazada
            }
            currentState = nextStates.iterator().next();
        }

        return dfa.isAcceptState(currentState);
    }

    /**
     * Tokeniza una cadena de entrada según el alfabeto del autómata.
     * Soporta tokens de múltiples caracteres (ej: "@bot", "cmd").
     *
     * @param input La cadena de texto a tokenizar
     * @param alphabet El alfabeto del autómata
     * @return Lista de tokens en orden, o null si hay token inválido
     */
    public List<String> tokenize(String input, Set<String> alphabet) {
        if (input == null || input.trim().isEmpty()) {
            return Collections.emptyList();
        }

        // Intentar tokenización por espacios primero (para alfabetos multi-carácter)
        String trimmed = input.trim();
        String[] parts = trimmed.split("\\s+");

        boolean multiCharAlphabet = alphabet.stream().anyMatch(s -> s.length() > 1);

        if (multiCharAlphabet) {
            // Verificar que todos los tokens del split pertenecen al alfabeto
            boolean allValid = true;
            for (String part : parts) {
                if (!alphabet.contains(part)) {
                    allValid = false;
                    break;
                }
            }
            if (allValid) {
                return Arrays.asList(parts);
            }
        }

        // Tokenización carácter a carácter para alfabetos de un solo carácter
        List<String> tokens = new ArrayList<>();
        for (char c : trimmed.toCharArray()) {
            String token = String.valueOf(c);
            if (!alphabet.contains(token)) {
                return null; // Token inválido
            }
            tokens.add(token);
        }
        return tokens;
    }
}
