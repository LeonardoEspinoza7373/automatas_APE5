package com.automata.service;

import com.automata.model.Automaton;
import com.automata.model.ConversionResult;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Servicio que implementa el Algoritmo de Minimización de AFD
 * mediante el Método de la Tabla de Equivalencia de Pares de Estados.
 *
 * Pasos del algoritmo:
 *  1. Identificar estados de aceptación y no aceptación.
 *  2. Construir tabla triangular de pares de estados.
 *  3. Marcar pares distinguibles (base: aceptación vs no aceptación).
 *  4. Iterar: marcar pares cuyos sucesores sean distinguibles.
 *  5. Fusionar estados equivalentes (no marcados).
 *  6. Construir el AFD mínimo.
 */
@Service
public class DfaMinimizationService {

    /**
     * Minimiza un AFD y registra todos los pasos del proceso.
     *
     * @param dfa El AFD a minimizar (resultado de la construcción de subconjuntos)
     * @param result El objeto resultado donde se registrarán los pasos
     * @return El AFD mínimo equivalente
     */
    public Automaton minimize(Automaton dfa, ConversionResult result) {
        List<String> states = new ArrayList<>(dfa.getStates());
        int n = states.size();
        List<ConversionResult.MinimizationStep> steps = new ArrayList<>();

        // Tabla de distinguibilidad: true = distinguible (marcado), false = posiblemente equivalente
        boolean[][] distinguishable = new boolean[n][n];

        // ── PASO 1: Marcar pares base ────────────────────────────────────────
        // Un estado de aceptación y uno de no aceptación siempre son distinguibles
        List<String> initialMarked = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                boolean iAccept = dfa.isAcceptState(states.get(i));
                boolean jAccept = dfa.isAcceptState(states.get(j));

                if (iAccept != jAccept) {
                    distinguishable[i][j] = true;
                    initialMarked.add(formatPair(states.get(i), states.get(j)));
                }
            }
        }

        ConversionResult.MinimizationStep step0 = new ConversionResult.MinimizationStep();
        step0.setIteration(0);
        step0.setDescription("Marcado inicial: pares (aceptación, no-aceptación) son distinguibles");
        step0.setMarkedPairs(new ArrayList<>(initialMarked));
        step0.setEquivalentPairs(getEquivalentPairs(states, distinguishable));
        steps.add(step0);

        // ── PASOS 2..N: Propagar distinguibilidad ───────────────────────────
        boolean changed = true;
        int iteration = 1;

        while (changed) {
            changed = false;
            List<String> newlyMarked = new ArrayList<>();

            for (int i = 0; i < n; i++) {
                for (int j = i + 1; j < n; j++) {
                    if (distinguishable[i][j]) continue; // ya marcado

                    String si = states.get(i);
                    String sj = states.get(j);

                    // Verificar si para algún símbolo los sucesores son distinguibles
                    for (String symbol : dfa.getAlphabet()) {
                        String nextI = getFirstNextState(dfa, si, symbol);
                        String nextJ = getFirstNextState(dfa, sj, symbol);

                        if (nextI == null || nextJ == null) continue;
                        if (nextI.equals(nextJ)) continue;

                        int ni = states.indexOf(nextI);
                        int nj = states.indexOf(nextJ);

                        if (ni < 0 || nj < 0) continue;

                        // Normalizar índices para la tabla triangular
                        int lo = Math.min(ni, nj);
                        int hi = Math.max(ni, nj);

                        if (lo < hi && distinguishable[lo][hi]) {
                            distinguishable[i][j] = true;
                            newlyMarked.add(formatPair(si, sj)
                                    + " (por símbolo '" + symbol + "': "
                                    + nextI + "≠" + nextJ + ")");
                            changed = true;
                            break;
                        }
                    }
                }
            }

            if (changed || iteration == 1) {
                ConversionResult.MinimizationStep step = new ConversionResult.MinimizationStep();
                step.setIteration(iteration);
                step.setDescription(changed
                        ? "Iteración " + iteration + ": nuevos pares marcados por propagación"
                        : "Iteración " + iteration + ": sin cambios → convergencia");
                step.setMarkedPairs(new ArrayList<>(newlyMarked));
                step.setEquivalentPairs(getEquivalentPairs(states, distinguishable));
                steps.add(step);
            }

            iteration++;
        }

        result.setMinimizationSteps(steps);

        // ── PASO FINAL: Construir AFD minimizado ─────────────────────────────
        return buildMinimizedDfa(dfa, states, distinguishable);
    }

    /**
     * Construye el AFD minimizado fusionando los estados equivalentes.
     */
    private Automaton buildMinimizedDfa(Automaton dfa, List<String> states,
                                         boolean[][] distinguishable) {
        int n = states.size();

        // Encontrar clases de equivalencia (Union-Find simplificado)
        int[] representative = new int[n];
        for (int i = 0; i < n; i++) representative[i] = i;

        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (!distinguishable[i][j]) {
                    // Estados i y j son equivalentes: fusionar
                    int repI = findRepresentative(representative, i);
                    int repJ = findRepresentative(representative, j);
                    if (repI != repJ) {
                        representative[repJ] = repI;
                    }
                }
            }
        }

        // Aplanar representatives
        for (int i = 0; i < n; i++) {
            representative[i] = findRepresentative(representative, i);
        }

        // Construir mapa: estado original → nombre del estado minimizado
        Map<Integer, String> classNames = new LinkedHashMap<>();
        int classCounter = 0;
        Map<Integer, Integer> classMap = new LinkedHashMap<>();

        for (int i = 0; i < n; i++) {
            int rep = representative[i];
            if (!classMap.containsKey(rep)) {
                classMap.put(rep, classCounter++);
            }
        }

        // Generar nombres para las clases
        for (Map.Entry<Integer, Integer> entry : classMap.entrySet()) {
            classNames.put(entry.getKey(), generateMinStateName(entry.getValue()));
        }

        // Construir el AFD minimizado
        Automaton minimized = new Automaton();
        minimized.setAlphabet(new LinkedHashSet<>(dfa.getAlphabet()));
        minimized.setType(Automaton.AutomatonType.MINIMIZED_DFA);

        // Agregar estados y definir estado inicial y de aceptación
        for (int i = 0; i < n; i++) {
            int rep = representative[i];
            String minStateName = classNames.get(rep);
            minimized.getStates().add(minStateName);

            if (states.get(i).equals(dfa.getInitialState())) {
                minimized.setInitialState(minStateName);
            }

            if (dfa.isAcceptState(states.get(i))) {
                minimized.getAcceptStates().add(minStateName);
            }
        }

        // Agregar transiciones (una por clase de equivalencia)
        Set<String> processedClasses = new HashSet<>();
        for (int i = 0; i < n; i++) {
            int rep = representative[i];
            String minStateName = classNames.get(rep);

            if (processedClasses.contains(minStateName)) continue;
            processedClasses.add(minStateName);

            for (String symbol : dfa.getAlphabet()) {
                String nextState = getFirstNextState(dfa, states.get(i), symbol);
                if (nextState != null) {
                    int nextIdx = states.indexOf(nextState);
                    if (nextIdx >= 0) {
                        int nextRep = representative[nextIdx];
                        String nextMinState = classNames.get(nextRep);
                        minimized.addTransition(minStateName, symbol, nextMinState);
                    }
                }
            }
        }

        return minimized;
    }

    /**
     * Encuentra el representante de una clase de equivalencia (path compression).
     */
    private int findRepresentative(int[] parent, int i) {
        if (parent[i] != i) {
            parent[i] = findRepresentative(parent, parent[i]);
        }
        return parent[i];
    }

    /**
     * Obtiene el primer estado destino de una transición determinista.
     */
    private String getFirstNextState(Automaton dfa, String state, String symbol) {
        Set<String> nextStates = dfa.getNextStates(state, symbol);
        return nextStates.isEmpty() ? null : nextStates.iterator().next();
    }

    /**
     * Obtiene la lista de pares equivalentes (no marcados) de la tabla actual.
     */
    private List<String> getEquivalentPairs(List<String> states, boolean[][] distinguishable) {
        List<String> equivalent = new ArrayList<>();
        for (int i = 0; i < states.size(); i++) {
            for (int j = i + 1; j < states.size(); j++) {
                if (!distinguishable[i][j]) {
                    equivalent.add(formatPair(states.get(i), states.get(j)));
                }
            }
        }
        return equivalent;
    }

    /**
     * Formatea un par de estados como "si,sj".
     */
    private String formatPair(String si, String sj) {
        return "(" + si + ", " + sj + ")";
    }

    /**
     * Genera nombres para los estados del AFD minimizado.
     */
    private String generateMinStateName(int index) {
        if (index == 0) return "q0'";
        return "q" + index + "'";
    }
}
