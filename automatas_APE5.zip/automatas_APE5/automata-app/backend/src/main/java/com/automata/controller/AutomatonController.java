package com.automata.controller;

import com.automata.dto.AutomatonRequest;
import com.automata.dto.VerificationRequest;
import com.automata.dto.VerificationResponse;
import com.automata.model.ConversionResult;
import com.automata.service.AutomatonService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Controlador REST principal para las operaciones de autómatas.
 *
 * Endpoints:
 *   POST /api/automaton/convert    → Convertir AFND → AFD → AFD Minimizado
 *   POST /api/automaton/verify     → Verificar cadenas contra los tres autómatas
 *   GET  /api/automaton/examples   → Obtener ejemplos predefinidos de la práctica
 */
@RestController
@RequestMapping("/api/automaton")
@CrossOrigin(origins = "*")
public class AutomatonController {

    private final AutomatonService automatonService;

    public AutomatonController(AutomatonService automatonService) {
        this.automatonService = automatonService;
    }

    /**
     * Convierte un AFND al AFD equivalente y luego lo minimiza.
     * Retorna el resultado completo con todos los pasos intermedios.
     */
    @PostMapping("/convert")
    public ResponseEntity<ConversionResult> convert(
            @Valid @RequestBody AutomatonRequest request) {
        ConversionResult result = automatonService.processConversion(request);
        return ResponseEntity.ok(result);
    }

    /**
     * Verifica un conjunto de cadenas contra los tres autómatas
     * para demostrar la equivalencia entre ellos.
     */
    @PostMapping("/verify")
    public ResponseEntity<VerificationResponse> verify(
            @RequestBody VerificationRequest request) {
        VerificationResponse response = automatonService.verifyStrings(request);
        return ResponseEntity.ok(response);
    }

    /**
     * Retorna los tres ejemplos predefinidos de la práctica APE 5
     * para facilitar la carga rápida en el frontend.
     */
    @GetMapping("/examples")
    public ResponseEntity<Object> getExamples() {
        return ResponseEntity.ok(buildPracticeExamples());
    }

    // ── Construcción de ejemplos de la práctica ──────────────────────────────

    private Object buildPracticeExamples() {
        return new Object() {
            public final ExampleData[] examples = {
                buildBioinformaticsExample(),
                buildEcommerceExample(),
                buildSlackExample()
            };
        };
    }

    private ExampleData buildBioinformaticsExample() {
        ExampleData ex = new ExampleData();
        ex.title = "Reconocimiento de Secuencias Genéticas (Bioinformática)";
        ex.description = "Patrón: K G X* F — Busca secuencias proteicas en cadenas de ADN";
        ex.pattern = "K G X* F";
        ex.nfa = new AutomatonRequest();
        ex.nfa.setStates(java.util.Arrays.asList("q0", "q1", "q2", "q3"));
        ex.nfa.setAlphabet(java.util.Arrays.asList("K", "G", "X", "F"));
        ex.nfa.setInitialState("q0");
        ex.nfa.setAcceptStates(java.util.Arrays.asList("q3"));
        ex.nfa.setTransitions(buildBioTransitions());
        ex.testStrings = java.util.Arrays.asList(
            "", "K", "F", "KGF", "KGX", "KGXF", "KXXF", "KGXXF",
            "KKKGF", "KGXFGF", "KKKKKK", "GGGGGG", "XXXXXX", "FFFFFF",
            "KGXXXXKKKFXXXF", "XKGXF", "KGXFX", "KGKGXF", "FKGXF", "KGXFGXF"
        );
        return ex;
    }

    private java.util.Map<String, java.util.Map<String, java.util.List<String>>> buildBioTransitions() {
        java.util.Map<String, java.util.Map<String, java.util.List<String>>> t = new java.util.LinkedHashMap<>();
        t.put("q0", new java.util.LinkedHashMap<>() {{
            put("K", java.util.Arrays.asList("q1", "q0"));
            put("G", java.util.Arrays.asList("q0"));
            put("X", java.util.Arrays.asList("q0"));
            put("F", java.util.Arrays.asList("q0"));
        }});
        t.put("q1", new java.util.LinkedHashMap<>() {{
            put("G", java.util.Arrays.asList("q2"));
        }});
        t.put("q2", new java.util.LinkedHashMap<>() {{
            put("K", java.util.Arrays.asList("q2"));
            put("G", java.util.Arrays.asList("q2"));
            put("X", java.util.Arrays.asList("q2"));
            put("F", java.util.Arrays.asList("q3", "q2"));
        }});
        t.put("q3", new java.util.LinkedHashMap<>());
        return t;
    }

    private ExampleData buildEcommerceExample() {
        ExampleData ex = new ExampleData();
        ex.title = "Analizador de Comportamiento de Usuario (E-commerce)";
        ex.description = "Patrón: HOME SEARCH+ CART — Comprador Potencial";
        ex.pattern = "H S+ C";
        ex.nfa = new AutomatonRequest();
        ex.nfa.setStates(java.util.Arrays.asList("q0", "q1", "q2", "q3"));
        ex.nfa.setAlphabet(java.util.Arrays.asList("H", "S", "C"));
        ex.nfa.setInitialState("q0");
        ex.nfa.setAcceptStates(java.util.Arrays.asList("q3"));
        ex.nfa.setTransitions(buildEcomTransitions());
        ex.testStrings = java.util.Arrays.asList(
            "", "H", "S", "C", "HC", "HSC", "HSS", "SSC", "HSSC",
            "HSSSC", "HSSSSSC", "HHHHH", "SSSSS", "CCCCC",
            "HSSSSSSSC", "HSCHSC", "HSSSSSS", "SHSC", "HSCC", "HSSSSSSSSSSSSSC"
        );
        return ex;
    }

    private java.util.Map<String, java.util.Map<String, java.util.List<String>>> buildEcomTransitions() {
        java.util.Map<String, java.util.Map<String, java.util.List<String>>> t = new java.util.LinkedHashMap<>();
        t.put("q0", new java.util.LinkedHashMap<>() {{
            put("H", java.util.Arrays.asList("q1"));
        }});
        t.put("q1", new java.util.LinkedHashMap<>() {{
            put("S", java.util.Arrays.asList("q2", "q1"));
        }});
        t.put("q2", new java.util.LinkedHashMap<>() {{
            put("C", java.util.Arrays.asList("q3"));
        }});
        t.put("q3", new java.util.LinkedHashMap<>());
        return t;
    }

    private ExampleData buildSlackExample() {
        ExampleData ex = new ExampleData();
        ex.title = "Validación de Sintaxis de Mensajería (Chat/Slack)";
        ex.description = "Patrón: @bot (USER)? (!cmd | ?help) — Comandos de bot";
        ex.pattern = "@bot (user)? (cmd | help)";
        ex.nfa = new AutomatonRequest();
        ex.nfa.setStates(java.util.Arrays.asList("q0", "q1", "q2", "q3"));
        ex.nfa.setAlphabet(java.util.Arrays.asList("@bot", "user", "cmd", "help"));
        ex.nfa.setInitialState("q0");
        ex.nfa.setAcceptStates(java.util.Arrays.asList("q3"));
        ex.nfa.setTransitions(buildSlackTransitions());
        ex.testStrings = java.util.Arrays.asList(
            "", "@bot", "user", "cmd", "help",
            "@bot cmd", "@bot help", "@bot user cmd", "@bot user help",
            "@bot user", "@bot @bot cmd", "@bot user user cmd",
            "user @bot cmd", "@bot cmd help", "@bot help cmd",
            "@bot user cmd help", "@bot user help @bot",
            "@bot help user", "@bot user help user", "@bot user @bot cmd"
        );
        return ex;
    }

    private java.util.Map<String, java.util.Map<String, java.util.List<String>>> buildSlackTransitions() {
        java.util.Map<String, java.util.Map<String, java.util.List<String>>> t = new java.util.LinkedHashMap<>();
        t.put("q0", new java.util.LinkedHashMap<>() {{
            put("@bot", java.util.Arrays.asList("q1"));
        }});
        // q1 tiene transición lambda a q2 (se maneja como epsilon-transición)
        t.put("q1", new java.util.LinkedHashMap<>() {{
            put("user", java.util.Arrays.asList("q2"));
            // lambda → q2 se modela pre-computando el epsilon-cierre
        }});
        t.put("q2", new java.util.LinkedHashMap<>() {{
            put("cmd", java.util.Arrays.asList("q3"));
            put("help", java.util.Arrays.asList("q3"));
        }});
        t.put("q3", new java.util.LinkedHashMap<>());
        return t;
    }

    // ── Clase interna para los datos de ejemplo ──────────────────────────────

    public static class ExampleData {
        public String title;
        public String description;
        public String pattern;
        public AutomatonRequest nfa;
        public java.util.List<String> testStrings;
    }
}
