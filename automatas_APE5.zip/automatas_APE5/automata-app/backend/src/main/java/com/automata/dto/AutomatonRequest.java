package com.automata.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.*;

/**
 * DTO para recibir la definición de un AFND desde el frontend.
 * Representa la quíntupla (Q, Σ, δ, q0, F).
 */
public class AutomatonRequest {

    @NotEmpty(message = "El conjunto de estados no puede estar vacío")
    private List<String> states;

    @NotEmpty(message = "El alfabeto no puede estar vacío")
    private List<String> alphabet;

    @NotNull(message = "El estado inicial es requerido")
    private String initialState;

    @NotEmpty(message = "Debe haber al menos un estado de aceptación")
    private List<String> acceptStates;

    /**
     * Tabla de transiciones.
     * Formato JSON: { "q0": { "a": ["q1","q2"], "b": ["q0"] }, ... }
     */
    private Map<String, Map<String, List<String>>> transitions;

    // ── Getters & Setters ────────────────────────────────────────────────────

    public List<String> getStates() { return states; }
    public void setStates(List<String> states) { this.states = states; }

    public List<String> getAlphabet() { return alphabet; }
    public void setAlphabet(List<String> alphabet) { this.alphabet = alphabet; }

    public String getInitialState() { return initialState; }
    public void setInitialState(String initialState) { this.initialState = initialState; }

    public List<String> getAcceptStates() { return acceptStates; }
    public void setAcceptStates(List<String> acceptStates) { this.acceptStates = acceptStates; }

    public Map<String, Map<String, List<String>>> getTransitions() { return transitions; }
    public void setTransitions(Map<String, Map<String, List<String>>> transitions) {
        this.transitions = transitions;
    }
}
