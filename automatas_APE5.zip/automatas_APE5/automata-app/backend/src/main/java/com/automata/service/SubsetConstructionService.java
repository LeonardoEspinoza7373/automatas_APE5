package com.automata.service;

import com.automata.model.Automaton;
import com.automata.model.ConversionResult;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Servicio que implementa el algoritmo de Construcción de Subconjuntos
 * para convertir un AFND a un AFD equivalente.
 *
 * Algoritmo: Para cada conjunto de estados del AFND, calcula el conjunto
 * de estados alcanzables con cada símbolo del alfabeto y lo convierte
 * en un nuevo estado del AFD.
 */
@Service
public class SubsetConstructionService {

    // Constante para el estado de error (conjunto vacío)
    private static final String ERROR_STATE = "ERR";

    /**
     * Convierte un AFND a AFD usando la construcción de subconjuntos.
     *
     * @param nfa El autómata finito no determinista de entrada
     * @param result El objeto resultado donde se registrarán los pasos
     * @return El AFD equivalente resultante
     */
    public Automaton convert(Automaton nfa, ConversionResult result) {
        Automaton dfa = new Automaton();
        dfa.setAlphabet(new LinkedHashSet<>(nfa.getAlphabet()));
        dfa.setType(Automaton.AutomatonType.DFA);

        List<ConversionResult.SubsetConstructionStep> steps = new ArrayList<>();

        // Mapa de conjuntos de estados AFND → nombre del estado AFD
        Map<Set<String>, String> stateMapping = new LinkedHashMap<>();

        // Cola de conjuntos pendientes de procesar
        Queue<Set<String>> pending = new LinkedList<>();

        // Inicializar con el estado inicial
        Set<String> initialSet = new LinkedHashSet<>();
        initialSet.add(nfa.getInitialState());

        String initialDfaState = generateStateName(0);
        stateMapping.put(initialSet, initialDfaState);
        pending.add(initialSet);

        dfa.setInitialState(initialDfaState);
        dfa.getStates().add(initialDfaState);

        if (nfa.containsAcceptState(initialSet)) {
            dfa.getAcceptStates().add(initialDfaState);
        }

        int stateCounter = 1;

        // Procesar cada conjunto de estados pendiente
        while (!pending.isEmpty()) {
            Set<String> currentSet = pending.poll();
            String currentDfaState = stateMapping.get(currentSet);

            ConversionResult.SubsetConstructionStep step = new ConversionResult.SubsetConstructionStep();
            step.setDfaState(currentDfaState);
            step.setNfaStates(new LinkedHashSet<>(currentSet));
            step.setAccept(nfa.containsAcceptState(currentSet));

            // Calcular transiciones para cada símbolo del alfabeto
            for (String symbol : nfa.getAlphabet()) {
                Set<String> nextSet = computeNextSet(nfa, currentSet, symbol);

                String nextDfaState;

                if (nextSet.isEmpty()) {
                    // Conjunto vacío → estado de error
                    nextDfaState = ERROR_STATE;
                    if (!dfa.getStates().contains(ERROR_STATE)) {
                        dfa.getStates().add(ERROR_STATE);
                        stateMapping.put(Collections.emptySet(), ERROR_STATE);
                    }
                } else if (stateMapping.containsKey(nextSet)) {
                    // Conjunto ya conocido → usar estado existente
                    nextDfaState = stateMapping.get(nextSet);
                } else {
                    // Conjunto nuevo → crear nuevo estado AFD
                    nextDfaState = generateStateName(stateCounter++);
                    stateMapping.put(nextSet, nextDfaState);
                    pending.add(nextSet);
                    dfa.getStates().add(nextDfaState);

                    if (nfa.containsAcceptState(nextSet)) {
                        dfa.getAcceptStates().add(nextDfaState);
                    }
                }

                dfa.addTransition(currentDfaState, symbol, nextDfaState);
                step.getTransitions().put(symbol, nextDfaState);
            }

            steps.add(step);
        }

        // Agregar transiciones del estado de error a sí mismo
        if (dfa.getStates().contains(ERROR_STATE)) {
            for (String symbol : nfa.getAlphabet()) {
                dfa.addTransition(ERROR_STATE, symbol, ERROR_STATE);
            }
        }

        result.setSubsetSteps(steps);

        // Enriquecer los pasos con el mapping de subconjuntos AFND
        enrichStepsWithMapping(steps, stateMapping, nfa);

        return dfa;
    }

    /**
     * Calcula el conjunto de estados alcanzables desde un conjunto de estados
     * AFND con un símbolo dado.
     */
    private Set<String> computeNextSet(Automaton nfa, Set<String> currentSet, String symbol) {
        Set<String> nextSet = new LinkedHashSet<>();
        for (String state : currentSet) {
            nextSet.addAll(nfa.getNextStates(state, symbol));
        }
        return nextSet;
    }

    /**
     * Genera el nombre de un estado AFD usando letras del alfabeto (A, B, C...).
     * Después de Z, usa AA, AB, etc.
     */
    private String generateStateName(int index) {
        if (index < 26) {
            return String.valueOf((char) ('A' + index));
        }
        int first = index / 26 - 1;
        int second = index % 26;
        return String.valueOf((char) ('A' + first)) + (char) ('A' + second);
    }

    /**
     * Enriquece los pasos con la información del mapping de subconjuntos.
     */
    private void enrichStepsWithMapping(
            List<ConversionResult.SubsetConstructionStep> steps,
            Map<Set<String>, String> stateMapping,
            Automaton nfa) {

        // El mapping inverso ya está en los pasos (nfaStates), no se necesita nada adicional
        // Los pasos ya contienen la información completa
    }

    /**
     * Cuenta el total de transiciones de un autómata.
     */
    public int countTransitions(Automaton automaton) {
        return automaton.getTransitions().values().stream()
                .mapToInt(m -> m.values().stream().mapToInt(Set::size).sum())
                .sum();
    }
}
